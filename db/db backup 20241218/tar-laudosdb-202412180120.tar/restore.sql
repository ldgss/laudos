--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4 (Ubuntu 16.4-1.pgdg22.04+2)
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE laudosdb;
--
-- Name: laudosdb; Type: DATABASE; Schema: -; Owner: laudosdbdba
--

CREATE DATABASE laudosdb WITH TEMPLATE = template0 ENCODING = 'SQL_ASCII' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE laudosdb OWNER TO laudosdbdba;

\connect laudosdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: laudosdb; Type: DATABASE PROPERTIES; Schema: -; Owner: laudosdbdba
--

ALTER DATABASE laudosdb SET "TimeZone" TO 'America/Argentina/Mendoza';


\connect laudosdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: verificar_cantidad_aportada(); Type: FUNCTION; Schema: public; Owner: laudosdbdba
--

CREATE FUNCTION public.verificar_cantidad_aportada() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    cantidad_original INT;
    cantidad_total_aportada INT;
BEGIN
    -- Obtener la cantidad original de la mercadería antecedente
    SELECT cantidad INTO cantidad_original 
    FROM mercaderia 
    WHERE id = NEW.mercaderia_antecedente;

    -- Sumar las cantidades ya aportadas por este antecedente (excluyendo la nueva)
    SELECT COALESCE(SUM(cantidad_tomada), 0) INTO cantidad_total_aportada
    FROM antecedentes 
    WHERE mercaderia_antecedente = NEW.mercaderia_antecedente
      AND id != NEW.id; -- Excluir la fila actual si es una actualización

    -- Agregar la nueva cantidad tomada
    cantidad_total_aportada := cantidad_total_aportada + NEW.cantidad_tomada;

    -- Verificar si la cantidad excede la cantidad original
    IF cantidad_total_aportada > cantidad_original THEN
        RAISE EXCEPTION 'Cantidad total tomada % supera la cantidad original % para el antecedente %',
                        cantidad_total_aportada, cantidad_original, NEW.mercaderia_antecedente;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.verificar_cantidad_aportada() OWNER TO laudosdbdba;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: acceso; Type: TABLE; Schema: public; Owner: laudosdbdba
--

CREATE TABLE public.acceso (
    id bigint NOT NULL,
    ip text NOT NULL,
    dispositivo text NOT NULL,
    usuario bigint NOT NULL,
    fecha_registro timestamp with time zone NOT NULL
);


ALTER TABLE public.acceso OWNER TO laudosdbdba;

--
-- Name: acceso_id_seq; Type: SEQUENCE; Schema: public; Owner: laudosdbdba
--

CREATE SEQUENCE public.acceso_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.acceso_id_seq OWNER TO laudosdbdba;

--
-- Name: acceso_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laudosdbdba
--

ALTER SEQUENCE public.acceso_id_seq OWNED BY public.acceso.id;


--
-- Name: bloqueado; Type: TABLE; Schema: public; Owner: laudosdbdba
--

CREATE TABLE public.bloqueado (
    id bigint NOT NULL,
    mercaderia bigint,
    hojalata bigint,
    extracto bigint,
    estado boolean NOT NULL,
    numero_planilla text NOT NULL,
    motivo bigint NOT NULL,
    observaciones text,
    responsable bigint NOT NULL,
    fecha_registro timestamp with time zone NOT NULL
);


ALTER TABLE public.bloqueado OWNER TO laudosdbdba;

--
-- Name: bloqueado_id_seq; Type: SEQUENCE; Schema: public; Owner: laudosdbdba
--

CREATE SEQUENCE public.bloqueado_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bloqueado_id_seq OWNER TO laudosdbdba;

--
-- Name: bloqueado_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laudosdbdba
--

ALTER SEQUENCE public.bloqueado_id_seq OWNED BY public.bloqueado.id;


--
-- Name: despacho; Type: TABLE; Schema: public; Owner: laudosdbdba
--

CREATE TABLE public.despacho (
    id bigint NOT NULL,
    mercaderia bigint,
    hojalata bigint,
    extracto bigint,
    responsable bigint NOT NULL,
    fecha_registro timestamp with time zone NOT NULL,
    orden_entrega bigint
);


ALTER TABLE public.despacho OWNER TO laudosdbdba;

--
-- Name: despacho_id_seq; Type: SEQUENCE; Schema: public; Owner: laudosdbdba
--

CREATE SEQUENCE public.despacho_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.despacho_id_seq OWNER TO laudosdbdba;

--
-- Name: despacho_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laudosdbdba
--

ALTER SEQUENCE public.despacho_id_seq OWNED BY public.despacho.id;


--
-- Name: tarea_comentario; Type: TABLE; Schema: public; Owner: laudosdbdba
--

CREATE TABLE public.tarea_comentario (
    id bigint NOT NULL,
    tarea bigint NOT NULL,
    comentario text NOT NULL,
    responsable bigint NOT NULL,
    fecha_registro timestamp with time zone NOT NULL
);


ALTER TABLE public.tarea_comentario OWNER TO laudosdbdba;

--
-- Name: estado_tareas_id_seq; Type: SEQUENCE; Schema: public; Owner: laudosdbdba
--

CREATE SEQUENCE public.estado_tareas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.estado_tareas_id_seq OWNER TO laudosdbdba;

--
-- Name: estado_tareas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laudosdbdba
--

ALTER SEQUENCE public.estado_tareas_id_seq OWNED BY public.tarea_comentario.id;


--
-- Name: extracto; Type: TABLE; Schema: public; Owner: laudosdbdba
--

CREATE TABLE public.extracto (
    id bigint NOT NULL,
    numero_unico text NOT NULL,
    producto text NOT NULL,
    fecha_elaboracion timestamp with time zone NOT NULL,
    lote text NOT NULL,
    brix numeric NOT NULL,
    numero_recipiente smallint NOT NULL,
    observaciones text,
    vto_meses bigint NOT NULL,
    responsable bigint NOT NULL,
    fecha_registro timestamp with time zone NOT NULL,
    den text NOT NULL
);


ALTER TABLE public.extracto OWNER TO laudosdbdba;

--
-- Name: extracto_id_seq; Type: SEQUENCE; Schema: public; Owner: laudosdbdba
--

CREATE SEQUENCE public.extracto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.extracto_id_seq OWNER TO laudosdbdba;

--
-- Name: extracto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laudosdbdba
--

ALTER SEQUENCE public.extracto_id_seq OWNED BY public.extracto.id;


--
-- Name: hojalata; Type: TABLE; Schema: public; Owner: laudosdbdba
--

CREATE TABLE public.hojalata (
    id bigint NOT NULL,
    producto text NOT NULL,
    observacion text,
    fecha_elaboracion timestamp with time zone NOT NULL,
    lote text NOT NULL,
    lote_cuerpo text,
    lote_tapa text,
    cantidad integer NOT NULL,
    numero_unico text NOT NULL,
    responsable bigint NOT NULL,
    vto_meses bigint NOT NULL,
    fecha_registro timestamp with time zone NOT NULL,
    den text NOT NULL
);


ALTER TABLE public.hojalata OWNER TO laudosdbdba;

--
-- Name: hojalata_id_seq; Type: SEQUENCE; Schema: public; Owner: laudosdbdba
--

CREATE SEQUENCE public.hojalata_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hojalata_id_seq OWNER TO laudosdbdba;

--
-- Name: hojalata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laudosdbdba
--

ALTER SEQUENCE public.hojalata_id_seq OWNED BY public.hojalata.id;


--
-- Name: insumo_envase; Type: TABLE; Schema: public; Owner: laudosdbdba
--

CREATE TABLE public.insumo_envase (
    id bigint NOT NULL,
    insumo text NOT NULL,
    codigo_insumo text NOT NULL,
    fecha_consumo timestamp with time zone NOT NULL,
    responsable bigint NOT NULL,
    fecha_registro timestamp with time zone NOT NULL,
    lote_insumo text NOT NULL,
    cantidad smallint NOT NULL
);


ALTER TABLE public.insumo_envase OWNER TO laudosdbdba;

--
-- Name: insumo_id_seq; Type: SEQUENCE; Schema: public; Owner: laudosdbdba
--

CREATE SEQUENCE public.insumo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.insumo_id_seq OWNER TO laudosdbdba;

--
-- Name: insumo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laudosdbdba
--

ALTER SEQUENCE public.insumo_id_seq OWNED BY public.insumo_envase.id;


--
-- Name: mercaderia; Type: TABLE; Schema: public; Owner: laudosdbdba
--

CREATE TABLE public.mercaderia (
    id bigint NOT NULL,
    producto text NOT NULL,
    observacion text,
    cantidad smallint NOT NULL,
    lote text NOT NULL,
    fecha_elaboracion timestamp with time zone,
    fecha_etiquetado timestamp with time zone,
    responsable bigint NOT NULL,
    numero_unico text NOT NULL,
    vto bigint NOT NULL,
    fecha_registro timestamp with time zone NOT NULL,
    fecha_encajonado timestamp with time zone,
    den text NOT NULL
);


ALTER TABLE public.mercaderia OWNER TO laudosdbdba;

--
-- Name: TABLE mercaderia; Type: COMMENT; Schema: public; Owner: laudosdbdba
--

COMMENT ON TABLE public.mercaderia IS 'v 201124';


--
-- Name: mercaderia_id_seq; Type: SEQUENCE; Schema: public; Owner: laudosdbdba
--

CREATE SEQUENCE public.mercaderia_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mercaderia_id_seq OWNER TO laudosdbdba;

--
-- Name: mercaderia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laudosdbdba
--

ALTER SEQUENCE public.mercaderia_id_seq OWNED BY public.mercaderia.id;


--
-- Name: reacondicionado_detalle; Type: TABLE; Schema: public; Owner: laudosdbdba
--

CREATE TABLE public.reacondicionado_detalle (
    id bigint NOT NULL,
    reacondicionado bigint NOT NULL,
    mercaderia bigint,
    cantidad smallint NOT NULL,
    reacondicionado_detalle bigint,
    fecha_registro timestamp with time zone NOT NULL,
    mercaderia_original bigint NOT NULL
);


ALTER TABLE public.reacondicionado_detalle OWNER TO laudosdbdba;

--
-- Name: mezcla_detalle_id_seq; Type: SEQUENCE; Schema: public; Owner: laudosdbdba
--

CREATE SEQUENCE public.mezcla_detalle_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mezcla_detalle_id_seq OWNER TO laudosdbdba;

--
-- Name: mezcla_detalle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laudosdbdba
--

ALTER SEQUENCE public.mezcla_detalle_id_seq OWNED BY public.reacondicionado_detalle.id;


--
-- Name: reacondicionado; Type: TABLE; Schema: public; Owner: laudosdbdba
--

CREATE TABLE public.reacondicionado (
    id bigint NOT NULL,
    numero_unico text NOT NULL,
    responsable bigint NOT NULL,
    fecha_registro timestamp with time zone NOT NULL,
    nueva_den text NOT NULL,
    observaciones text,
    tipo_reacondicionado text NOT NULL
);


ALTER TABLE public.reacondicionado OWNER TO laudosdbdba;

--
-- Name: mezcla_id_seq; Type: SEQUENCE; Schema: public; Owner: laudosdbdba
--

CREATE SEQUENCE public.mezcla_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mezcla_id_seq OWNER TO laudosdbdba;

--
-- Name: mezcla_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laudosdbdba
--

ALTER SEQUENCE public.mezcla_id_seq OWNED BY public.reacondicionado.id;


--
-- Name: motivo_bloqueo; Type: TABLE; Schema: public; Owner: laudosdbdba
--

CREATE TABLE public.motivo_bloqueo (
    id bigint NOT NULL,
    motivo text NOT NULL,
    mercaderia boolean NOT NULL,
    hojalata boolean NOT NULL,
    responsable bigint NOT NULL,
    fecha_registro timestamp with time zone NOT NULL,
    extracto boolean NOT NULL
);


ALTER TABLE public.motivo_bloqueo OWNER TO laudosdbdba;

--
-- Name: motivo_bloqueo_id_seq; Type: SEQUENCE; Schema: public; Owner: laudosdbdba
--

CREATE SEQUENCE public.motivo_bloqueo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.motivo_bloqueo_id_seq OWNER TO laudosdbdba;

--
-- Name: motivo_bloqueo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laudosdbdba
--

ALTER SEQUENCE public.motivo_bloqueo_id_seq OWNED BY public.motivo_bloqueo.id;


--
-- Name: permiso; Type: TABLE; Schema: public; Owner: laudosdbdba
--

CREATE TABLE public.permiso (
    id bigint NOT NULL,
    mercaderia boolean NOT NULL,
    hojalata boolean NOT NULL,
    ubicacion boolean NOT NULL,
    bloqueo boolean NOT NULL,
    usuario boolean NOT NULL,
    despacho boolean NOT NULL,
    insumo boolean NOT NULL,
    extracto boolean NOT NULL,
    acceso boolean NOT NULL,
    motivo_bloqueo boolean NOT NULL,
    permiso boolean NOT NULL,
    vencimiento boolean NOT NULL,
    responsable bigint NOT NULL,
    fecha_registro timestamp with time zone NOT NULL
);


ALTER TABLE public.permiso OWNER TO laudosdbdba;

--
-- Name: permiso_id_seq; Type: SEQUENCE; Schema: public; Owner: laudosdbdba
--

CREATE SEQUENCE public.permiso_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.permiso_id_seq OWNER TO laudosdbdba;

--
-- Name: permiso_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laudosdbdba
--

ALTER SEQUENCE public.permiso_id_seq OWNED BY public.permiso.id;


--
-- Name: tarea; Type: TABLE; Schema: public; Owner: laudosdbdba
--

CREATE TABLE public.tarea (
    id bigint NOT NULL,
    tarea text NOT NULL,
    responsable bigint NOT NULL,
    fecha_registro timestamp with time zone NOT NULL,
    hecho boolean NOT NULL
);


ALTER TABLE public.tarea OWNER TO laudosdbdba;

--
-- Name: tareas_id_seq; Type: SEQUENCE; Schema: public; Owner: laudosdbdba
--

CREATE SEQUENCE public.tareas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tareas_id_seq OWNER TO laudosdbdba;

--
-- Name: tareas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laudosdbdba
--

ALTER SEQUENCE public.tareas_id_seq OWNED BY public.tarea.id;


--
-- Name: ubicacion; Type: TABLE; Schema: public; Owner: laudosdbdba
--

CREATE TABLE public.ubicacion (
    id bigint NOT NULL,
    ubicacion_fila bigint NOT NULL,
    mercaderia text,
    hojalata text,
    extracto text,
    responsable bigint NOT NULL,
    fecha_registro timestamp with time zone NOT NULL,
    insumo_envase text,
    ubicacion_profundidad smallint NOT NULL,
    ubicacion_altura smallint NOT NULL,
    reacondicionado text
);


ALTER TABLE public.ubicacion OWNER TO laudosdbdba;

--
-- Name: ubicacion_id_seq; Type: SEQUENCE; Schema: public; Owner: laudosdbdba
--

CREATE SEQUENCE public.ubicacion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ubicacion_id_seq OWNER TO laudosdbdba;

--
-- Name: ubicacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laudosdbdba
--

ALTER SEQUENCE public.ubicacion_id_seq OWNED BY public.ubicacion.id;


--
-- Name: ubicacion_nombre; Type: TABLE; Schema: public; Owner: laudosdbdba
--

CREATE TABLE public.ubicacion_nombre (
    id bigint NOT NULL,
    posicion text NOT NULL,
    sector text NOT NULL,
    fecha_registro timestamp with time zone NOT NULL
);


ALTER TABLE public.ubicacion_nombre OWNER TO laudosdbdba;

--
-- Name: ubicaciones_nombres_id_seq; Type: SEQUENCE; Schema: public; Owner: laudosdbdba
--

CREATE SEQUENCE public.ubicaciones_nombres_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ubicaciones_nombres_id_seq OWNER TO laudosdbdba;

--
-- Name: ubicaciones_nombres_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laudosdbdba
--

ALTER SEQUENCE public.ubicaciones_nombres_id_seq OWNED BY public.ubicacion_nombre.id;


--
-- Name: usuario; Type: TABLE; Schema: public; Owner: laudosdbdba
--

CREATE TABLE public.usuario (
    id bigint NOT NULL,
    nombre text NOT NULL,
    password text NOT NULL,
    fecha_creacion timestamp with time zone NOT NULL,
    fecha_modificacion timestamp with time zone NOT NULL,
    esta_activo boolean NOT NULL
);


ALTER TABLE public.usuario OWNER TO laudosdbdba;

--
-- Name: usuario_id_seq; Type: SEQUENCE; Schema: public; Owner: laudosdbdba
--

CREATE SEQUENCE public.usuario_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usuario_id_seq OWNER TO laudosdbdba;

--
-- Name: usuario_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laudosdbdba
--

ALTER SEQUENCE public.usuario_id_seq OWNED BY public.usuario.id;


--
-- Name: vencimiento; Type: TABLE; Schema: public; Owner: laudosdbdba
--

CREATE TABLE public.vencimiento (
    id bigint NOT NULL,
    producto text NOT NULL,
    meses smallint NOT NULL,
    responsable bigint NOT NULL,
    fecha_registro timestamp with time zone NOT NULL
);


ALTER TABLE public.vencimiento OWNER TO laudosdbdba;

--
-- Name: vencimiento_id_seq; Type: SEQUENCE; Schema: public; Owner: laudosdbdba
--

CREATE SEQUENCE public.vencimiento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vencimiento_id_seq OWNER TO laudosdbdba;

--
-- Name: vencimiento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laudosdbdba
--

ALTER SEQUENCE public.vencimiento_id_seq OWNED BY public.vencimiento.id;


--
-- Name: acceso id; Type: DEFAULT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.acceso ALTER COLUMN id SET DEFAULT nextval('public.acceso_id_seq'::regclass);


--
-- Name: bloqueado id; Type: DEFAULT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.bloqueado ALTER COLUMN id SET DEFAULT nextval('public.bloqueado_id_seq'::regclass);


--
-- Name: despacho id; Type: DEFAULT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.despacho ALTER COLUMN id SET DEFAULT nextval('public.despacho_id_seq'::regclass);


--
-- Name: extracto id; Type: DEFAULT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.extracto ALTER COLUMN id SET DEFAULT nextval('public.extracto_id_seq'::regclass);


--
-- Name: hojalata id; Type: DEFAULT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.hojalata ALTER COLUMN id SET DEFAULT nextval('public.hojalata_id_seq'::regclass);


--
-- Name: insumo_envase id; Type: DEFAULT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.insumo_envase ALTER COLUMN id SET DEFAULT nextval('public.insumo_id_seq'::regclass);


--
-- Name: mercaderia id; Type: DEFAULT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.mercaderia ALTER COLUMN id SET DEFAULT nextval('public.mercaderia_id_seq'::regclass);


--
-- Name: motivo_bloqueo id; Type: DEFAULT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.motivo_bloqueo ALTER COLUMN id SET DEFAULT nextval('public.motivo_bloqueo_id_seq'::regclass);


--
-- Name: permiso id; Type: DEFAULT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.permiso ALTER COLUMN id SET DEFAULT nextval('public.permiso_id_seq'::regclass);


--
-- Name: reacondicionado id; Type: DEFAULT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.reacondicionado ALTER COLUMN id SET DEFAULT nextval('public.mezcla_id_seq'::regclass);


--
-- Name: reacondicionado_detalle id; Type: DEFAULT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.reacondicionado_detalle ALTER COLUMN id SET DEFAULT nextval('public.mezcla_detalle_id_seq'::regclass);


--
-- Name: tarea id; Type: DEFAULT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.tarea ALTER COLUMN id SET DEFAULT nextval('public.tareas_id_seq'::regclass);


--
-- Name: tarea_comentario id; Type: DEFAULT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.tarea_comentario ALTER COLUMN id SET DEFAULT nextval('public.estado_tareas_id_seq'::regclass);


--
-- Name: ubicacion id; Type: DEFAULT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.ubicacion ALTER COLUMN id SET DEFAULT nextval('public.ubicacion_id_seq'::regclass);


--
-- Name: ubicacion_nombre id; Type: DEFAULT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.ubicacion_nombre ALTER COLUMN id SET DEFAULT nextval('public.ubicaciones_nombres_id_seq'::regclass);


--
-- Name: usuario id; Type: DEFAULT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.usuario ALTER COLUMN id SET DEFAULT nextval('public.usuario_id_seq'::regclass);


--
-- Name: vencimiento id; Type: DEFAULT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.vencimiento ALTER COLUMN id SET DEFAULT nextval('public.vencimiento_id_seq'::regclass);


--
-- Data for Name: acceso; Type: TABLE DATA; Schema: public; Owner: laudosdbdba
--

COPY public.acceso (id, ip, dispositivo, usuario, fecha_registro) FROM stdin;
\.
COPY public.acceso (id, ip, dispositivo, usuario, fecha_registro) FROM '$$PATH$$/3501.dat';

--
-- Data for Name: bloqueado; Type: TABLE DATA; Schema: public; Owner: laudosdbdba
--

COPY public.bloqueado (id, mercaderia, hojalata, extracto, estado, numero_planilla, motivo, observaciones, responsable, fecha_registro) FROM stdin;
\.
COPY public.bloqueado (id, mercaderia, hojalata, extracto, estado, numero_planilla, motivo, observaciones, responsable, fecha_registro) FROM '$$PATH$$/3503.dat';

--
-- Data for Name: despacho; Type: TABLE DATA; Schema: public; Owner: laudosdbdba
--

COPY public.despacho (id, mercaderia, hojalata, extracto, responsable, fecha_registro, orden_entrega) FROM stdin;
\.
COPY public.despacho (id, mercaderia, hojalata, extracto, responsable, fecha_registro, orden_entrega) FROM '$$PATH$$/3505.dat';

--
-- Data for Name: extracto; Type: TABLE DATA; Schema: public; Owner: laudosdbdba
--

COPY public.extracto (id, numero_unico, producto, fecha_elaboracion, lote, brix, numero_recipiente, observaciones, vto_meses, responsable, fecha_registro, den) FROM stdin;
\.
COPY public.extracto (id, numero_unico, producto, fecha_elaboracion, lote, brix, numero_recipiente, observaciones, vto_meses, responsable, fecha_registro, den) FROM '$$PATH$$/3509.dat';

--
-- Data for Name: hojalata; Type: TABLE DATA; Schema: public; Owner: laudosdbdba
--

COPY public.hojalata (id, producto, observacion, fecha_elaboracion, lote, lote_cuerpo, lote_tapa, cantidad, numero_unico, responsable, vto_meses, fecha_registro, den) FROM stdin;
\.
COPY public.hojalata (id, producto, observacion, fecha_elaboracion, lote, lote_cuerpo, lote_tapa, cantidad, numero_unico, responsable, vto_meses, fecha_registro, den) FROM '$$PATH$$/3511.dat';

--
-- Data for Name: insumo_envase; Type: TABLE DATA; Schema: public; Owner: laudosdbdba
--

COPY public.insumo_envase (id, insumo, codigo_insumo, fecha_consumo, responsable, fecha_registro, lote_insumo, cantidad) FROM stdin;
\.
COPY public.insumo_envase (id, insumo, codigo_insumo, fecha_consumo, responsable, fecha_registro, lote_insumo, cantidad) FROM '$$PATH$$/3513.dat';

--
-- Data for Name: mercaderia; Type: TABLE DATA; Schema: public; Owner: laudosdbdba
--

COPY public.mercaderia (id, producto, observacion, cantidad, lote, fecha_elaboracion, fecha_etiquetado, responsable, numero_unico, vto, fecha_registro, fecha_encajonado, den) FROM stdin;
\.
COPY public.mercaderia (id, producto, observacion, cantidad, lote, fecha_elaboracion, fecha_etiquetado, responsable, numero_unico, vto, fecha_registro, fecha_encajonado, den) FROM '$$PATH$$/3515.dat';

--
-- Data for Name: motivo_bloqueo; Type: TABLE DATA; Schema: public; Owner: laudosdbdba
--

COPY public.motivo_bloqueo (id, motivo, mercaderia, hojalata, responsable, fecha_registro, extracto) FROM stdin;
\.
COPY public.motivo_bloqueo (id, motivo, mercaderia, hojalata, responsable, fecha_registro, extracto) FROM '$$PATH$$/3521.dat';

--
-- Data for Name: permiso; Type: TABLE DATA; Schema: public; Owner: laudosdbdba
--

COPY public.permiso (id, mercaderia, hojalata, ubicacion, bloqueo, usuario, despacho, insumo, extracto, acceso, motivo_bloqueo, permiso, vencimiento, responsable, fecha_registro) FROM stdin;
\.
COPY public.permiso (id, mercaderia, hojalata, ubicacion, bloqueo, usuario, despacho, insumo, extracto, acceso, motivo_bloqueo, permiso, vencimiento, responsable, fecha_registro) FROM '$$PATH$$/3523.dat';

--
-- Data for Name: reacondicionado; Type: TABLE DATA; Schema: public; Owner: laudosdbdba
--

COPY public.reacondicionado (id, numero_unico, responsable, fecha_registro, nueva_den, observaciones, tipo_reacondicionado) FROM stdin;
\.
COPY public.reacondicionado (id, numero_unico, responsable, fecha_registro, nueva_den, observaciones, tipo_reacondicionado) FROM '$$PATH$$/3519.dat';

--
-- Data for Name: reacondicionado_detalle; Type: TABLE DATA; Schema: public; Owner: laudosdbdba
--

COPY public.reacondicionado_detalle (id, reacondicionado, mercaderia, cantidad, reacondicionado_detalle, fecha_registro, mercaderia_original) FROM stdin;
\.
COPY public.reacondicionado_detalle (id, reacondicionado, mercaderia, cantidad, reacondicionado_detalle, fecha_registro, mercaderia_original) FROM '$$PATH$$/3517.dat';

--
-- Data for Name: tarea; Type: TABLE DATA; Schema: public; Owner: laudosdbdba
--

COPY public.tarea (id, tarea, responsable, fecha_registro, hecho) FROM stdin;
\.
COPY public.tarea (id, tarea, responsable, fecha_registro, hecho) FROM '$$PATH$$/3525.dat';

--
-- Data for Name: tarea_comentario; Type: TABLE DATA; Schema: public; Owner: laudosdbdba
--

COPY public.tarea_comentario (id, tarea, comentario, responsable, fecha_registro) FROM stdin;
\.
COPY public.tarea_comentario (id, tarea, comentario, responsable, fecha_registro) FROM '$$PATH$$/3507.dat';

--
-- Data for Name: ubicacion; Type: TABLE DATA; Schema: public; Owner: laudosdbdba
--

COPY public.ubicacion (id, ubicacion_fila, mercaderia, hojalata, extracto, responsable, fecha_registro, insumo_envase, ubicacion_profundidad, ubicacion_altura, reacondicionado) FROM stdin;
\.
COPY public.ubicacion (id, ubicacion_fila, mercaderia, hojalata, extracto, responsable, fecha_registro, insumo_envase, ubicacion_profundidad, ubicacion_altura, reacondicionado) FROM '$$PATH$$/3527.dat';

--
-- Data for Name: ubicacion_nombre; Type: TABLE DATA; Schema: public; Owner: laudosdbdba
--

COPY public.ubicacion_nombre (id, posicion, sector, fecha_registro) FROM stdin;
\.
COPY public.ubicacion_nombre (id, posicion, sector, fecha_registro) FROM '$$PATH$$/3529.dat';

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: laudosdbdba
--

COPY public.usuario (id, nombre, password, fecha_creacion, fecha_modificacion, esta_activo) FROM stdin;
\.
COPY public.usuario (id, nombre, password, fecha_creacion, fecha_modificacion, esta_activo) FROM '$$PATH$$/3531.dat';

--
-- Data for Name: vencimiento; Type: TABLE DATA; Schema: public; Owner: laudosdbdba
--

COPY public.vencimiento (id, producto, meses, responsable, fecha_registro) FROM stdin;
\.
COPY public.vencimiento (id, producto, meses, responsable, fecha_registro) FROM '$$PATH$$/3533.dat';

--
-- Name: acceso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laudosdbdba
--

SELECT pg_catalog.setval('public.acceso_id_seq', 326, true);


--
-- Name: bloqueado_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laudosdbdba
--

SELECT pg_catalog.setval('public.bloqueado_id_seq', 1, false);


--
-- Name: despacho_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laudosdbdba
--

SELECT pg_catalog.setval('public.despacho_id_seq', 1, false);


--
-- Name: estado_tareas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laudosdbdba
--

SELECT pg_catalog.setval('public.estado_tareas_id_seq', 1, false);


--
-- Name: extracto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laudosdbdba
--

SELECT pg_catalog.setval('public.extracto_id_seq', 22, true);


--
-- Name: hojalata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laudosdbdba
--

SELECT pg_catalog.setval('public.hojalata_id_seq', 1, false);


--
-- Name: insumo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laudosdbdba
--

SELECT pg_catalog.setval('public.insumo_id_seq', 4, true);


--
-- Name: mercaderia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laudosdbdba
--

SELECT pg_catalog.setval('public.mercaderia_id_seq', 184, true);


--
-- Name: mezcla_detalle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laudosdbdba
--

SELECT pg_catalog.setval('public.mezcla_detalle_id_seq', 167, true);


--
-- Name: mezcla_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laudosdbdba
--

SELECT pg_catalog.setval('public.mezcla_id_seq', 91, true);


--
-- Name: motivo_bloqueo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laudosdbdba
--

SELECT pg_catalog.setval('public.motivo_bloqueo_id_seq', 24, true);


--
-- Name: permiso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laudosdbdba
--

SELECT pg_catalog.setval('public.permiso_id_seq', 20, true);


--
-- Name: tareas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laudosdbdba
--

SELECT pg_catalog.setval('public.tareas_id_seq', 1, false);


--
-- Name: ubicacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laudosdbdba
--

SELECT pg_catalog.setval('public.ubicacion_id_seq', 46, true);


--
-- Name: ubicaciones_nombres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laudosdbdba
--

SELECT pg_catalog.setval('public.ubicaciones_nombres_id_seq', 318, true);


--
-- Name: usuario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laudosdbdba
--

SELECT pg_catalog.setval('public.usuario_id_seq', 19, true);


--
-- Name: vencimiento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laudosdbdba
--

SELECT pg_catalog.setval('public.vencimiento_id_seq', 12, true);


--
-- Name: acceso acceso_pkey; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.acceso
    ADD CONSTRAINT acceso_pkey PRIMARY KEY (id);


--
-- Name: bloqueado bloqueado_pkey; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.bloqueado
    ADD CONSTRAINT bloqueado_pkey PRIMARY KEY (id);


--
-- Name: despacho despacho_pkey; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.despacho
    ADD CONSTRAINT despacho_pkey PRIMARY KEY (id);


--
-- Name: tarea_comentario estado_tareas_pkey; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.tarea_comentario
    ADD CONSTRAINT estado_tareas_pkey PRIMARY KEY (id);


--
-- Name: extracto extracto_numero_unico; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.extracto
    ADD CONSTRAINT extracto_numero_unico UNIQUE (numero_unico);


--
-- Name: extracto extracto_pkey; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.extracto
    ADD CONSTRAINT extracto_pkey PRIMARY KEY (id);


--
-- Name: hojalata hojalata_numero_unico; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.hojalata
    ADD CONSTRAINT hojalata_numero_unico UNIQUE (numero_unico);


--
-- Name: hojalata hojalata_pkey; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.hojalata
    ADD CONSTRAINT hojalata_pkey PRIMARY KEY (id);


--
-- Name: insumo_envase insumo_pkey; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.insumo_envase
    ADD CONSTRAINT insumo_pkey PRIMARY KEY (id);


--
-- Name: mercaderia mercaderia_pkey; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.mercaderia
    ADD CONSTRAINT mercaderia_pkey PRIMARY KEY (id);


--
-- Name: reacondicionado_detalle mezcla_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.reacondicionado_detalle
    ADD CONSTRAINT mezcla_detalle_pkey PRIMARY KEY (id);


--
-- Name: reacondicionado mezcla_pkey; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.reacondicionado
    ADD CONSTRAINT mezcla_pkey PRIMARY KEY (id);


--
-- Name: motivo_bloqueo motivo_bloqueo_pkey; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.motivo_bloqueo
    ADD CONSTRAINT motivo_bloqueo_pkey PRIMARY KEY (id);


--
-- Name: reacondicionado numero_unico_unique; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.reacondicionado
    ADD CONSTRAINT numero_unico_unique UNIQUE (numero_unico);


--
-- Name: permiso permiso_pkey; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.permiso
    ADD CONSTRAINT permiso_pkey PRIMARY KEY (id);


--
-- Name: tarea tareas_pkey; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.tarea
    ADD CONSTRAINT tareas_pkey PRIMARY KEY (id);


--
-- Name: ubicacion ubicacion_pkey; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.ubicacion
    ADD CONSTRAINT ubicacion_pkey PRIMARY KEY (id);


--
-- Name: ubicacion_nombre ubicaciones_nombres_pkey; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.ubicacion_nombre
    ADD CONSTRAINT ubicaciones_nombres_pkey PRIMARY KEY (id);


--
-- Name: mercaderia unique_numero_unico; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.mercaderia
    ADD CONSTRAINT unique_numero_unico UNIQUE (numero_unico);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (id);


--
-- Name: vencimiento vencimiento_pkey; Type: CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.vencimiento
    ADD CONSTRAINT vencimiento_pkey PRIMARY KEY (id);


--
-- Name: reacondicionado_detalle FK__mercaderia; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.reacondicionado_detalle
    ADD CONSTRAINT "FK__mercaderia" FOREIGN KEY (mercaderia) REFERENCES public.mercaderia(id);


--
-- Name: reacondicionado_detalle FK__mezcla; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.reacondicionado_detalle
    ADD CONSTRAINT "FK__mezcla" FOREIGN KEY (reacondicionado) REFERENCES public.reacondicionado(id);


--
-- Name: tarea_comentario FK__tareas; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.tarea_comentario
    ADD CONSTRAINT "FK__tareas" FOREIGN KEY (tarea) REFERENCES public.tarea(id);


--
-- Name: tarea FK__usuario; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.tarea
    ADD CONSTRAINT "FK__usuario" FOREIGN KEY (responsable) REFERENCES public.usuario(id);


--
-- Name: tarea_comentario FK__usuario; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.tarea_comentario
    ADD CONSTRAINT "FK__usuario" FOREIGN KEY (responsable) REFERENCES public.usuario(id);


--
-- Name: reacondicionado FK__usuario; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.reacondicionado
    ADD CONSTRAINT "FK__usuario" FOREIGN KEY (responsable) REFERENCES public.usuario(id);


--
-- Name: acceso FK_acceso_usuario; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.acceso
    ADD CONSTRAINT "FK_acceso_usuario" FOREIGN KEY (usuario) REFERENCES public.usuario(id);


--
-- Name: bloqueado FK_bloqueado_extracto; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.bloqueado
    ADD CONSTRAINT "FK_bloqueado_extracto" FOREIGN KEY (extracto) REFERENCES public.extracto(id);


--
-- Name: bloqueado FK_bloqueado_hojalata; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.bloqueado
    ADD CONSTRAINT "FK_bloqueado_hojalata" FOREIGN KEY (hojalata) REFERENCES public.hojalata(id);


--
-- Name: bloqueado FK_bloqueado_mercaderia; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.bloqueado
    ADD CONSTRAINT "FK_bloqueado_mercaderia" FOREIGN KEY (mercaderia) REFERENCES public.mercaderia(id);


--
-- Name: bloqueado FK_bloqueado_motivo_bloqueo; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.bloqueado
    ADD CONSTRAINT "FK_bloqueado_motivo_bloqueo" FOREIGN KEY (motivo) REFERENCES public.motivo_bloqueo(id);


--
-- Name: bloqueado FK_bloqueado_usuario; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.bloqueado
    ADD CONSTRAINT "FK_bloqueado_usuario" FOREIGN KEY (responsable) REFERENCES public.usuario(id);


--
-- Name: despacho FK_despacho_extracto; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.despacho
    ADD CONSTRAINT "FK_despacho_extracto" FOREIGN KEY (extracto) REFERENCES public.extracto(id);


--
-- Name: despacho FK_despacho_hojalata; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.despacho
    ADD CONSTRAINT "FK_despacho_hojalata" FOREIGN KEY (hojalata) REFERENCES public.hojalata(id);


--
-- Name: despacho FK_despacho_mercaderia; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.despacho
    ADD CONSTRAINT "FK_despacho_mercaderia" FOREIGN KEY (mercaderia) REFERENCES public.mercaderia(id);


--
-- Name: despacho FK_despacho_usuario; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.despacho
    ADD CONSTRAINT "FK_despacho_usuario" FOREIGN KEY (responsable) REFERENCES public.usuario(id);


--
-- Name: extracto FK_extracto_usuario; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.extracto
    ADD CONSTRAINT "FK_extracto_usuario" FOREIGN KEY (responsable) REFERENCES public.usuario(id);


--
-- Name: extracto FK_extracto_vencimiento; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.extracto
    ADD CONSTRAINT "FK_extracto_vencimiento" FOREIGN KEY (vto_meses) REFERENCES public.vencimiento(id);


--
-- Name: hojalata FK_hojalata_usuario; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.hojalata
    ADD CONSTRAINT "FK_hojalata_usuario" FOREIGN KEY (responsable) REFERENCES public.usuario(id);


--
-- Name: hojalata FK_hojalata_vencimiento; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.hojalata
    ADD CONSTRAINT "FK_hojalata_vencimiento" FOREIGN KEY (vto_meses) REFERENCES public.vencimiento(id);


--
-- Name: insumo_envase FK_insumo_usuario; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.insumo_envase
    ADD CONSTRAINT "FK_insumo_usuario" FOREIGN KEY (responsable) REFERENCES public.usuario(id);


--
-- Name: mercaderia FK_mercaderia_usuario; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.mercaderia
    ADD CONSTRAINT "FK_mercaderia_usuario" FOREIGN KEY (responsable) REFERENCES public.usuario(id);


--
-- Name: mercaderia FK_mercaderia_vencimiento; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.mercaderia
    ADD CONSTRAINT "FK_mercaderia_vencimiento" FOREIGN KEY (vto) REFERENCES public.vencimiento(id);


--
-- Name: reacondicionado_detalle FK_mezcla_detalle_mezcla_detalle; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.reacondicionado_detalle
    ADD CONSTRAINT "FK_mezcla_detalle_mezcla_detalle" FOREIGN KEY (reacondicionado_detalle) REFERENCES public.reacondicionado_detalle(id);


--
-- Name: motivo_bloqueo FK_motivo_bloqueo_usuario; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.motivo_bloqueo
    ADD CONSTRAINT "FK_motivo_bloqueo_usuario" FOREIGN KEY (responsable) REFERENCES public.usuario(id);


--
-- Name: permiso FK_permiso_usuario; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.permiso
    ADD CONSTRAINT "FK_permiso_usuario" FOREIGN KEY (responsable) REFERENCES public.usuario(id);


--
-- Name: reacondicionado_detalle FK_reacondicionado_detalle_mercaderia; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.reacondicionado_detalle
    ADD CONSTRAINT "FK_reacondicionado_detalle_mercaderia" FOREIGN KEY (mercaderia_original) REFERENCES public.mercaderia(id);


--
-- Name: ubicacion FK_ubicacion_extracto; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.ubicacion
    ADD CONSTRAINT "FK_ubicacion_extracto" FOREIGN KEY (extracto) REFERENCES public.extracto(numero_unico);


--
-- Name: ubicacion FK_ubicacion_hojalata; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.ubicacion
    ADD CONSTRAINT "FK_ubicacion_hojalata" FOREIGN KEY (hojalata) REFERENCES public.hojalata(numero_unico);


--
-- Name: ubicacion FK_ubicacion_mercaderia; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.ubicacion
    ADD CONSTRAINT "FK_ubicacion_mercaderia" FOREIGN KEY (mercaderia) REFERENCES public.mercaderia(numero_unico);


--
-- Name: ubicacion FK_ubicacion_reacondicionado; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.ubicacion
    ADD CONSTRAINT "FK_ubicacion_reacondicionado" FOREIGN KEY (reacondicionado) REFERENCES public.reacondicionado(numero_unico);


--
-- Name: ubicacion FK_ubicacion_ubicaciones_nombres; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.ubicacion
    ADD CONSTRAINT "FK_ubicacion_ubicaciones_nombres" FOREIGN KEY (ubicacion_fila) REFERENCES public.ubicacion_nombre(id);


--
-- Name: ubicacion FK_ubicacion_usuario; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.ubicacion
    ADD CONSTRAINT "FK_ubicacion_usuario" FOREIGN KEY (responsable) REFERENCES public.usuario(id);


--
-- Name: vencimiento FK_vencimiento_usuario; Type: FK CONSTRAINT; Schema: public; Owner: laudosdbdba
--

ALTER TABLE ONLY public.vencimiento
    ADD CONSTRAINT "FK_vencimiento_usuario" FOREIGN KEY (responsable) REFERENCES public.usuario(id);


--
-- Name: TABLE acceso; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.acceso TO laudosdbusr;


--
-- Name: SEQUENCE acceso_id_seq; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT USAGE ON SEQUENCE public.acceso_id_seq TO laudosdbusr;


--
-- Name: TABLE bloqueado; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.bloqueado TO laudosdbusr;


--
-- Name: SEQUENCE bloqueado_id_seq; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT USAGE ON SEQUENCE public.bloqueado_id_seq TO laudosdbusr;


--
-- Name: TABLE despacho; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.despacho TO laudosdbusr;


--
-- Name: SEQUENCE despacho_id_seq; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT USAGE ON SEQUENCE public.despacho_id_seq TO laudosdbusr;


--
-- Name: TABLE tarea_comentario; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tarea_comentario TO laudosdbusr;


--
-- Name: SEQUENCE estado_tareas_id_seq; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT USAGE ON SEQUENCE public.estado_tareas_id_seq TO laudosdbusr;


--
-- Name: TABLE extracto; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.extracto TO laudosdbusr;


--
-- Name: SEQUENCE extracto_id_seq; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT USAGE ON SEQUENCE public.extracto_id_seq TO laudosdbusr;


--
-- Name: TABLE hojalata; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.hojalata TO laudosdbusr;


--
-- Name: SEQUENCE hojalata_id_seq; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT USAGE ON SEQUENCE public.hojalata_id_seq TO laudosdbusr;


--
-- Name: TABLE insumo_envase; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.insumo_envase TO laudosdbusr;


--
-- Name: SEQUENCE insumo_id_seq; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT USAGE ON SEQUENCE public.insumo_id_seq TO laudosdbusr;


--
-- Name: TABLE mercaderia; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.mercaderia TO laudosdbusr;


--
-- Name: SEQUENCE mercaderia_id_seq; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT USAGE ON SEQUENCE public.mercaderia_id_seq TO laudosdbusr;


--
-- Name: TABLE reacondicionado_detalle; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.reacondicionado_detalle TO laudosdbusr;


--
-- Name: SEQUENCE mezcla_detalle_id_seq; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT USAGE ON SEQUENCE public.mezcla_detalle_id_seq TO laudosdbusr;


--
-- Name: TABLE reacondicionado; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.reacondicionado TO laudosdbusr;


--
-- Name: SEQUENCE mezcla_id_seq; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT USAGE ON SEQUENCE public.mezcla_id_seq TO laudosdbusr;


--
-- Name: TABLE motivo_bloqueo; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.motivo_bloqueo TO laudosdbusr;


--
-- Name: SEQUENCE motivo_bloqueo_id_seq; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT USAGE ON SEQUENCE public.motivo_bloqueo_id_seq TO laudosdbusr;


--
-- Name: TABLE permiso; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.permiso TO laudosdbusr;


--
-- Name: SEQUENCE permiso_id_seq; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT USAGE ON SEQUENCE public.permiso_id_seq TO laudosdbusr;


--
-- Name: TABLE tarea; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tarea TO laudosdbusr;


--
-- Name: SEQUENCE tareas_id_seq; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT USAGE ON SEQUENCE public.tareas_id_seq TO laudosdbusr;


--
-- Name: TABLE ubicacion; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ubicacion TO laudosdbusr;


--
-- Name: SEQUENCE ubicacion_id_seq; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT USAGE ON SEQUENCE public.ubicacion_id_seq TO laudosdbusr;


--
-- Name: TABLE ubicacion_nombre; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ubicacion_nombre TO laudosdbusr;


--
-- Name: SEQUENCE ubicaciones_nombres_id_seq; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT USAGE ON SEQUENCE public.ubicaciones_nombres_id_seq TO laudosdbusr;


--
-- Name: TABLE usuario; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.usuario TO laudosdbusr;


--
-- Name: SEQUENCE usuario_id_seq; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT USAGE ON SEQUENCE public.usuario_id_seq TO laudosdbusr;


--
-- Name: TABLE vencimiento; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.vencimiento TO laudosdbusr;


--
-- Name: SEQUENCE vencimiento_id_seq; Type: ACL; Schema: public; Owner: laudosdbdba
--

GRANT USAGE ON SEQUENCE public.vencimiento_id_seq TO laudosdbusr;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO laudosdbusr;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: laudosdbdba
--

ALTER DEFAULT PRIVILEGES FOR ROLE laudosdbdba IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO laudosdbusr;


--
-- PostgreSQL database dump complete
--

